import ProjetoChatBot as chat

nome_bot = 'jarvis'
chat.saudacao(nome_bot)
while True:
    texto = chat.recebeMsg()
    resposta = chat.buscaResposta(f'Cliente: {texto} \n')
    if chat.exibeResposta(texto, resposta, nome_bot) == 'fim':
        break

