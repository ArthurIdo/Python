def saudacao(nome):
    import random
    frases = ['Aoba', 'Bom-dia!', 'eai', 'Ola! Tudo bem?', 'Fala Fiote', 'shiiiiiiiiiiiiiii']
    quantidade_frases = len(frases) -1
    print(frases[random.randint(0, quantidade_frases)])

def saudacao_GUI(nome):
    import random
    frases = ['Aoba', 'Bom-dia!', 'eai', 'Ola! Tudo bem?', 'Fala Fiote', 'shiiiiiiiiiiiiiii']
    quantidade_frases = len(frases) - 1
    return(frases[random.randint(0, quantidade_frases)])

def recebeMsg():
    msg = input('Cliente: ')
    palavrasProibidas = ['fdp', 'chato', 'bobão']
    for palavra in palavrasProibidas:
        if str(palavra.upper()) in str(msg.upper()):
            print('Não pode xingar fdp')
            return recebeMsg()
    return msg

def buscaResposta(texto):
    conhecimento = open('base_conhecimento.txt', 'a+')
    conhecimento.seek(0)
    while True:
        viu = conhecimento.readline()
        if viu != '':
            if texto == viu:
                proximaLinha = conhecimento.readline()
                if 'Chatbot: ' in proximaLinha:
                    return proximaLinha

        else:
            print('me desculpe, não sei oque falar')
            conhecimento.write(texto)
            resposta_usuario = input('oque voce esperava? \n')
            conhecimento.write(f'Chatbot: {resposta_usuario} \n')
            return 'Hum...'

def buscaResposta_GUI(texto):
    with open('base_conhecimento.txt', 'a+') as conhecimento:
        conhecimento.seek(0)
        while True:
            viu = conhecimento.read()
            if viu != "":
                if jaccard(texto, viu)>0.3:
                    proximaLinha = conhecimento.readline()
                    if 'Chatbot: ' in proximaLinha:
                        return proximaLinha
            else:
                conhecimento.write(texto)
                return 'Me desculpe, não sei oque falar'

def jaccard(textoUsuario, textoBase):
    textoUsuario = limpa_frase(textoUsuario)
    textoBase = limpa_frase(textoBase)
    if len(textoBase)<1: return 0
    else:
        palavras_em_comum = 0
        for palavra in textoUsuario.split():
            if palavra in textoBase.split():
                palavras_em_comum +=1
        return palavras_em_comum/len(textoUsuario.split()) + len(textoBase.split()) -(len(textoBase.split(' ')))

def limpa_frase(frase):
    tirar = ['?', ':', ';', '/', '...', '.', ',', 'Cliente: ', '\n']
    for t in tirar:
        frase = frase.replace(t, '')
    frase = frase.upper()
    return frase

def exibeResposta(texto, resposta, nome):
    print(resposta.replace('Chatbot', nome))
    if texto == 'tenho que ir':
        print('tudo bem, te espero na proxima, até ja´!!')
        return 'fim'
    return 'continua'

def exibeResposta_GUI(texto, resposta, nome):
    return resposta.replace('chatbot', nome)

def salva_sugestao(sugestao):
    with open('base_conhecimento.txt', ' a+') as conhecimento:
        conhecimento.write(f'Chatbot: {sugestao} \n')